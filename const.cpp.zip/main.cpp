/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
void func(int &a, const int &b);
int main()
{
    int alpha=7;
    int beta=11;
    func(alpha,beta);
    return 0;
}
void func(int &a, const int &b)
{
    a=107;
    b=111;
    cout<<a<<","<<b;
}
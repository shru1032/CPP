/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// Program to input matrix from user and display it on screen 
#include <iostream>
using namespace std;
int disp(int arr1[20][20], int r, int c);
int main()
{
    int arr[20][20]; int r,c;
    cout<<"Enter the number of rows in the matrix: ";
    cin>>r;
    cout<<"Enter the number of columns in the matrix: ";
    cin>>c;
    int i,j;
    for(i=0;i<r;i++)
    {
        for (j=0;j<c;j++)
        {
            cout<<"Enter the "<<i<<","<<j<<" element of the matrix: ";
            cin>>arr[i][j];
        }
    }
    disp(arr,r,c);
    return 0;
}

int disp(int arr1[20][20], int r, int c)
{
    cout<<"The matrix is:\n";
    int i,j;
    for(i=0;i<r;i++)
    {
        for(j=0;j<c;j++)
        {
            cout<<arr1[i][j]<<"\t";
        }
        cout<<"\n";
    }
    return 0;
}

/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


#include <iostream>
#include <string.h>
using namespace std;

class animals
{
    protected:
    string s;
    public:
    animals()
    {
        cout<<"Inside class Animals\n";
    }
    virtual void sound() //Virtual Function
    {
        cout<<"Different animals make different sounds\n";
    }
};

class dog:public animals
{
    public:
    dog()
    {
        cout<<"Inside class dog\n";
    }
    void sound()
    {
        s="Bow-wow!";
        cout<<"Dogs make the sound: "<<s<<endl;
    }
};

class cat:public animals 
{
    public:
    cat()
    {
        cout<<"Inside class cat\n";
    }
    void sound()
    {
        s="Meow-meow!";
        cout<<"Cats make the sount: "<<s<<endl;
    }
};

int main()
{
    animals *ptr;
    animals a1;
    ptr = &a1;
    ptr->sound();
    dog d1;
    ptr = &d1;
    ptr->sound();
    cat c1;
    ptr = &c1;
    ptr->sound();
}

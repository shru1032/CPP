/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

class animal
{
    public:
    animal()
    {
        cout<<"Different animals make different sounds.\n";
    }
};

class bark:public animal
{
    public:
    bark()
    {
        cout<<"A dog barks.\n";
    }
};

class dog:public bark
{
    public:
    dog()
    {
        cout<<"Bow-wow!\n";
    }
};

int main()
{
    dog d1;
}
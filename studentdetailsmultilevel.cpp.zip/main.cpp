/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <cstdlib>
#include <string>
using namespace std;

class student //Base class
{
    private:
        string name;
        int age; 
        char id[100];
    public:
        student() //Default Constructor
        {
            age=19;
        }
        void details() //To get student details
        {
            cout<<"Enter the student details here:\n";
            cout<<"Enter the name of the student: ";
            getline(cin,name);
            cout<<"Enter the student ID: ";
            cin>>id;
        }
        void print() //To display student details
        {
            cout<<"\n";
            cout<<"--------Student Details---------\n";
            cout<<"\n";
            cout<<"Name: "<<name<<"\n";
            cout<<"Student ID: "<<id<<"\n";
            cout<<"Student Age: "<<age<<"\n";
        }
};
class exam:public student //Publically derived class
{
    protected:
        float marks[6];
    public:
        void input() //To get marks as input
        {
            int i;
            cout<<"Enter the marks of 6 subjects(Out of 100):\n";
            for(i=0;i<6;i++)
            {
                cout<<"Enter marks for subject-"<<i+1<<": ";
                cin>>marks[i];
            }
        }
        void output() //To display marks 
        {
            print();
            cout<<"Marks in 6 subjects:\n";
            for(int i=0;i<6;i++)
            {
                cout<<marks[i]<<"\t";
            }
            cout<<"\n";
        }
};
class result:public exam //Publically derived class
{
    private:
        float sum=0;
    public:
        void res() //To calculate sum
        {
            for(int i=0;i<6;i++)
            {
                sum=sum+marks[i];
            }
        }
        void out() //To display result
        {
            output();
            cout<<"The sum of marks: "<<sum<<"\n";
            cout<<"Percentage of the student: "<<((sum/600)*100);
        }
};

int main()
{
    char ch;
    do{
    result s1;
    s1.details();
    s1.input();
    s1.res();
    s1.out();
    cout<<"\nCalculate percentage for more students?(y/n): ";
    cin>>ch;
    }while(ch=='y'||ch=='Y');
    return 0;
}



/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

class A 
{
    protected:
    int x;
    public:
    A()
    {
        x=0;
    }
    A(int c)
    {
        x=c;
    }
    int get()
    {
        return x;
    }
};

class B:public A 
{
    public:
    void input()
    {
        cin>>x;
    }
    void factorial()
    {
        long int fact=1;
        for(int i=1;i<=x;i++)
        {
            fact=fact*i;
        }
        cout<<fact;
    }
};

int main()
{
    A a1,a2;
    B b1,b2;
    int c= a1.get();
    cout<<c<<"\n";
    int d=b1.get();
    cout<<d;
    cout<<"\nInput: ";
    b1.input();
    cout<<"Factorial: ";
    b1.factorial();
    int e=a1.get();
    cout<<"\n"<<e;
    return 0;
}


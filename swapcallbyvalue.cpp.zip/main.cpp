/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// Swapping 2 numbers using call by value
#include <iostream>
using namespace std;

int main()
{
    int x,y;
    cout<<"Enter the first number: ";
    cin>>x;
    cout<<"Enter the second number: ";
    cin>>y;
    cout<<"Numbers before swapping are:\n";
    cout<<x<<"\t"<<y;
    swap(x,y);
    cout<<"\nNumbers after swapping are:\n";
    cout<<x<<"\t"<<y;
    return 0;
}

int swap(int x, int y)
{
    int temp;
    temp=x;
    x=y;
    x=temp;
    return 0;
}

/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

// square and cube hierarchical inheritance

#include <iostream>
using namespace std;

class Number
{
public:
    static int num;
    void getNumber()
    {
        cout << "Enter a number: ";
        cin >> num;
    }
    int returnNumber()
    {
        return num;
    }
};

int Number::num;
class Square : public Number
{
  public:
    int getSquare()
    {
        int sqr;
        int n = returnNumber();
        sqr = n*n;
        return sqr;
    }
};

class Cube : public Number
{
public:
    int getCube()
    {
        int cube;
        int n = returnNumber();
        cube = n*n*n;
        return cube;
    }
};

int main()
{
    Number num;
    Square objS;
    Cube objC; 
    num.getNumber();
    cout << "Square of " << num.returnNumber() << " = " << objS.getSquare() << endl;
    cout << "Cube of " << num.returnNumber() << " = " << objC.getCube() << endl; 
    return 0;
}

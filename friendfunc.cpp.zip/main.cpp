/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class b;
class a 
{
    private: 
    int data;
    public:
    a()
    {data=3;}
    friend int frifunc(a,b); //Friend function
};
class b
{
    private:
    int data;
    public:
    b()
    {data=7;}
    friend int frifunc(a,b);
};
int frifunc(a a1,b b1) //Friend function definition
{
    cout<<a1.data<<" and "<<b1.data;
}

int main()
{
    a a1;
    b b1;
    frifunc(a1,b1);
    return 0;
}

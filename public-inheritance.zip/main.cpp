/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Public Inheritance

#include <iostream>
using namespace std;

class A //Base class
{
    private:
    int privdataA=1;
    protected:
    int protdataA=2;
    public:
    int pubdataA=3;
};
class B:public A //Publically derived class
{
    public:
    int a;
    int func()
    {
        //a=privdataA; //Error 
        a=protdataA; //OK //a=2
        a=pubdataA; //OK //a=3
        return a; //a=3
    }
    void display()
    {
        cout<<a<<"\t";
    }
};
int main()
{
    int b=0;
    A a1;
    B b1;
    b1.func();
    b1.display();
    //b=b1.privdataA; //Error
    cout<<b<<"\t"; //b=0
    //b=b1.protdataA; //Error
    cout<<b<<"\t"; //b=0
    b=b1.pubdataA; //OK //b=3
    cout<<b<<"\t"; //b=3
}

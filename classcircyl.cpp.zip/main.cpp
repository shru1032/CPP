/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Program to find the area of circle and cylinder by virtual Function runtime Polymorphism overloading concept

#include <iostream>
using namespace std;

class circle
{
    protected:
    float radius;
    float a;
    public:
    circle(float r)
    {
        radius=r;
    }
    virtual void area() //Virtual Function
    {
        a=3.14*radius*radius;
        cout<<"Area of the circle is: "<<a<<endl;
    }
};

class cylinder:public circle
{
    private:
    float height;
    public:
    cylinder(float r, float h):circle(r)
    {
        radius=r;
        height=h;
    }
    void area()
    {
        a= (2*3.14*radius*height) + (3.14*radius*radius);
        cout<<"TSA of cylinder is: "<<a<<endl;
    }
};

int main()
{
    float r,h;
    cout<<"Enter radius of circle: ";
    cin>>r;
    circle *ptr;
    circle cir1(r);
    ptr=&cir1;
    ptr->area();
    cout<<"Enter radius and height of cylinder: ";
    cin>>r>>h;
    cylinder cylr1(r,h);
    ptr=&cylr1;
    ptr->area();
}


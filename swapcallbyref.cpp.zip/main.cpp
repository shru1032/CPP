/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <iostream>
using namespace std;
int swap(int &x, int &y);
int main()
{
    int a,b;
    cout<<"Enter A:";
    cin>>a;
    cout<<"Enter b:";
    cin>>b;
    cout<<"After swapping: ";
    swap(a,b);
    return 0;
}

int swap(int &x, int &y)
{
    int t;
    t=x;
    x=y;
    y=t;
    cout<<x<<" "<<y;
    return 0;
}
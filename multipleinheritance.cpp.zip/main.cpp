/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <iostream>
using namespace std;

class animal
{
    public:
    animal()
    {
        cout<<"Different animals make different sounds.\n";
    }
};

class dog : public animal
{
    public:
    dog()
    {
        cout<<"A dog barks.\tBow-wow!\n";
    }
};

class cat : public animal
{
    public:
    cat()
    {
        cout<<"A cat meows.\tMeow-meow!\n";
    }
};

int main()
{
    dog d1;
    cat c1;
}
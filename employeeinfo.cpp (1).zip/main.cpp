/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <conio.h>
#include <string.h>
using namespace std;

class employee
{
    public:
    string name;
    int salary;
    employee()
    {
        salary=50000;
    }
    employee(int s)
    {
        salary=s;
    }
    void getname()
    {
        cout<<"Enter name of the employee: ";
        getline(cin,name);
    }
    void dispname()
    {
        cout<<"Name: "<<name<<endl;
    }
};

class details:public employee
{
    int empid;
    int workexp;
    public:
    void getdetails()
    {
        cout<<"Enter Employee ID: ";
        cin>>empid;
        cout<<"Enter work years: ";
        cin>>workexp;
    }
    void dispdetails()
    {
        dispname();
        cout<<"Employee ID: "<<empid<<endl;
        cout<<"Work Year: "<<workexp<<endl;
    }
};

class pf : public employee
{
    public:
    int getsalary(employee e1)
    {
        return e1.salary;
    }
};


int main()
{
    employee emp1;
    details d1;
    d1.getname();
    d1.getdetails();
    cout<<"The employee details are as follows:\n";
    d1.dispdetails();
    pf obj1;
    cout<<"The salary of the employee is: "<<obj1.getsalary(emp1);
}
    
/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <string.h>
using namespace std;

class Media //Abstract class
{
protected:
    string title;
    string pub;

public:
    virtual void read() = 0; //Pure Virtual functions 
    virtual void show() = 0; //Pure virtual functions
};

class Book : public Media //Derived class
{
    int pages;

public:
    void read()
    {
        cout << "Enter the title of the book: " << endl;
        getline(cin,title);
        cout << "Enter the name of publication: " << endl;
        getline(cin,pub);
        cout << "Enter the number of pages: " << endl;
        cin >> pages;
    }
    void show()
    {
        cout << "Title: " << title << endl;
        cout << "Name of publication: " << pub << endl;
        cout << "Number of pages: " << pages << endl;
    }
};

class VideoTapes : public Media //Derived class
{
    float time;

public:
    void read()
    {
        cout << "Enter the title of the video: " << endl;
        getline(cin>>ws,title);
        cout << "Enter the name of publication: " << endl;
        getline(cin,pub);
        cout << "Enter the playing time (in sec): " << endl;
        cin >> time;
    }
    void show()
    {
        cout << "Title: " << title << endl;
        cout << "Name of publication: " << pub << endl;
        cout << "Number of playing time: " << time << "sec" << endl;
    }
};

int main()
{
    Media * M1;
    Media *M2;
    Book bookobject;
    VideoTapes videoobject;

    M1 = &bookobject;
    M2 = &videoobject;

    M1->read();
    cout<<"The details of the book are:\n";
    M1->show();
    M2->read();
    cout<<"The details of the videotape are:\n";
    M2->show();
    
    return 0;
}


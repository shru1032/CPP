/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Program to find largest of 3 numbers using macros
#include <iostream>
using namespace std;

#define LARGEST(a,b,c) ((a>b)?(a>c?a:c):(b>c?b:c));

int main()
{
    int x,y,z,large;
    cout<<"Enter the first number: ";
    cin>>x;
    cout<<"Enter the second number: ";
    cin>>y;
    cout<<"Enter the third number: ";
    cin>>z;
    large= LARGEST(x,y,z);
    cout<<"The largest of three numbers is: "<<large;
    return 0;
}


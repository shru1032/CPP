/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <iostream>

class student
{
    private:
    char admid[50];
    int marks;
    char grade[10];
    int fee_paid;
    public:
    char name[100];
    char address[200];
    int age;
    void input()
    {
        std::cout<<"Enter the student details here:\n";
        std::cin>>name>>address>>age>>marks>>grade;
    }
    void display()
    {
        std::cout<<"Student details are:\n";
        std::cout<<name<<"\n"<<address<<"\n"<<age<<"\n"<<marks<<"\n"<<grade;
    }
    void initialize()
    {
        fee_paid=150000;
        std::cout<<"\n"<<fee_paid<<"\n";
    }
};
int main()
{
    student s1,s2;
    s1.input();
    s1.display();
    s1.initialize();
    s2.input();
    s2.display();
    s2.initialize();
    return 0;
}
/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Protected Inheritance

#include <iostream>
using namespace std;

class A //Base class
{
    private:
    int privdataA=1;
    protected:
    int protdataA=2;
    public:
    int pubdataA=3;
};
class B:protected A //Protectedly derived class
{
    public:
    int a;
    int func()
    {
        //a=privdataA; //Error
        a=protdataA; //OK
        a=pubdataA; //OK
        return a;
    }
    void display()
    {
        cout<<a<<"\t";
    }
};
int main()
{
    int b=0;
    A a1;
    B b1;
    b1.func();
    b1.display();
    //b=b1.privdataA; //Error
    cout<<b<<"\t";
    //b=b1.protdataA; //Error
    cout<<b<<"\t";
    //b=b1.pubdataA; //Error
    cout<<b<<"\t";
}
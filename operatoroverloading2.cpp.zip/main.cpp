/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;

class increment
{
    private:
    int value;
    public:
    increment(int x)
    {
        value=x;
    }
    
    void operator +()
    {
        ++value;
    }
    
    void display()
    {
        cout<<"After increment: "<<value<<endl;
    }
};

int main()
{
    int y;
    cout<<"Enter value: ";
    cin>>y;
    increment count1(y);
    +count1;
    count1.display();
    return 0;
}
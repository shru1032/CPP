/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

// Program demonstrating function overloading
#include <iostream>
using namespace std;
int sum(int a, int b);
int sum(int a, int b, int c);
int sum(int a, int b, int c, int d);

int main()
{
    int a,b,c,d;
    
    cout<<"For 2 arguments:\n";
    cout<<"Enter 2 numbers here: ";
    cin>>a>>b;
    cout<<"Addition of "<<a<<" & "<<b<<" is "<<sum(a,b);
    cout<<"\n";
    
    cout<<"For 3 arguments:\n";
    cout<<"Enter 3 numbers here: ";
    cin>>a>>b>>c;
    cout<<"Addition of "<<a<<", "<<b<<" & "<<c<<" is "<<sum(a,b,c);
    cout<<"\n";
    
    cout<<"For 4 arguments:\n";
    cout<<"Enter 4 numbers here: ";
    cin>>a>>b>>c>>d;
    cout<<"Addition of "<<a<<", "<<b<<", "<<c<<" & "<<d<<" is "<<sum(a,b,c,d);
    cout<<"\n";
}

//Function with 2 arguments 
int sum(int a, int b)
{
    int sum=0;
    sum=a+b;
    return sum;
}

//Function with 3 arguments 
int sum(int a, int b, int c)
{
    int sum=0;
    sum=a+b+c;
    return sum;
}

//Function with 4 arguments 
int sum(int a, int b, int c, int d)
{
    int sum=0;
    sum=a+b+c+d;
    return sum;
}
/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

//Program to demonstrate exception handling in Compile++.

#include <iostream>
using namespace std;
double zeroDivision(int x, int y) 
{
  
    if (y == 0) 
    {
        throw "Division by Zero!";
    }
    return (x / y);
}
  
int main() 
{
    int a;
    int b;
    double c = 0;
    
    cout<<"Enter a: ";
    cin>>a;
    cout<<"Enter b: ";
    cin>>b;
    
    try 
    {
        c = zeroDivision(a, b);
        cout << c << endl;
    }
    catch (const char* message) 
    {
        cerr << message << endl;
    }
    return 0;
}
/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Program to find largest of 3 numbers using inline functions
#include <iostream>
using namespace std;
inline int largest(int x, int y, int z);
int main()
{
    int a,b,c;
    cout<<"Enter 3 numbers to find the largest:\n";
    cout<<"a= ";
    cin>>a;
    cout<<"b= ";
    cin>>b;
    cout<<"c= ";
    cin>>c;
    cout<<"The largest of "<<a<<", "<<b<<", "<<c<<" is "<< largest(a,b,c);
    return 0;
}

inline int largest(int x, int y, int z)
{
    if (x>y)
    {
        if (x>z)
            return x;
        else
            return z;
    }
    else
    {
        if (y>z)
            return y;
        else
            return z;
    }
}

/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

class Time 
{
    private:
    int hours, minutes;
    public:
    void input()
    {
        cout<<"Enter hours1: ";
        cin>>hours;
        cout<<"Enter minutes1: ";
        cin>>minutes;
    }
    void display()
    {
        cout<<hours<<":"<<minutes;
    }
    void sum(Time t1, Time t2)
    {
        minutes= t1.minutes + t2.minutes;
        hours=minutes/60;
        minutes=minutes%60;
        hours=hours+t1.hours+t2.hours;
    }
};

int main()
{
    Time t1,t2,t3;
    t1.input();
    t2.input();
    t3.sum(t1,t2);
    t3.display();
    return 0;
}

/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Program to demonstrate file handling in C++.

#include <iostream>
#include <fstream>
#include <string.h>
using namespace std;

int main() 
{
	fstream my_file;
	my_file.open("my_file", ios::out);
	if (!my_file) {
		cout << "File not created!\n";
	}
	else {
		cout << "File created successfully!\n";
		my_file<<"This is a program to demonstrate file handling in C++.\n";
		my_file.close(); 
	}
	my_file.open("my_file", ios::in);
	if (!my_file)
	{
	    cout<< "File not found!\n";
	}
	else
	{
	    char ch;
	    my_file >> noskipws;
	    while (my_file)
	    {
	        my_file>>ch;
	        cout<<ch;
	    }
	    my_file.close();
	}
	return 0;
}
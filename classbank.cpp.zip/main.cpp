/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <iostream>
using namespace std;

class bank_account
{
    private:
    long int customer_id;
    char customer_name[100];
    long int account_num;
    float opening_balance;
    public:
        void deposit(){}
        void withdraw(){}
        bank_account(int o)
        {
            opening_balance=o;
        }
        bank_account()
        {
            opening_balance=10000;
        }
        void input()
        {
            cout<<"Enter name: ";
            cin>>customer_name;
            cout<<"Enter customer ID: ";
            cin>>customer_id;
            cout<<"Enter account number: ";
            cin>>account_num;
        }
        void display()
        {
            cout<<"Customer details are:\n";
            cout<<"Name: "<<customer_name<<"\n"<<"Cutomer ID: "<<customer_id<<"\n"<<"Acccount No.: "<<account_num<<"\n"<<"Opening balance: "<<opening_balance<<"\n";
        }
};

int main()
{
    bank_account customer1(2000), customer2(2000), customer3, customer4;
    customer1.input();
    customer1.display();
    customer3.input();
    customer3.display();
    return 0;
}

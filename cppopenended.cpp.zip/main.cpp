/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

//Tax units generator system for Sona Island

#include <iostream>
using namespace std;

class Tax
{
    private:
    int initTax, slot1, slot2, k, years;
    long long int tot_tax;
    
    public:
    void getdata();
    long long int sum(long long int arr[], int count);
    long long int total();
    void display_total();
};

void Tax::getdata()
{
        cout<<"Enter k: ";
        cin>>k;
        cout<<"Enter the initial tax: ";
        cin>>initTax;
        cout<<"Enter slot 1 years: ";
        cin>>slot1;
        cout<<"Enter slot 2 years: ";
        cin>>slot2;
        cout<<"Enter further years: ";
        cin>>years;
}

long long int Tax::sum(long long int arr[], int count)
{
   int i;
   long long int sum=0;
   for (i=0;i<count;i++)
   {
       sum=sum+arr[i];
   }
   return sum;
}

long long int Tax::total()
{
    int count=1+slot1+slot2+years;
    long long int tax[100];
    tax[0]=initTax;
    int i,j;
    
    for (i=1;i<1+slot1;i++)
    {
        tax[i]=tax[i-1]+1;
    }
    for (i=slot1+1;i<1+slot1+slot2;i++)
    {
        tax[i]=2*tax[i-1];
    }
    for (i=1+slot1+slot2;i<1+slot1+slot2+years;i++)
    {
        long int t=1;
        int j;
        for (j=i-1;j>=i-k;j--)
        {
            t=t*tax[j];
        }
        tax[i]=t;
    }
    
    long long int tot_tax=sum(tax, count);
    return tot_tax;
}

void Tax::display_total()
{
    cout<<"Total tax units to be paid are: "<<total()<<" units"<<endl;
}
    
int main()
{
    int ch;
    do
    {
        Tax t1;
        t1.getdata();
        t1.total();
        t1.display_total();
        cout<<"Press 1 to generate another total: ";
        cin>>ch;
    } while (ch==1);
    return 0;
}


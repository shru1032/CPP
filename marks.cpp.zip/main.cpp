/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <conio.h>
using namespace std;

class student
{
    protected:
    int rollno;
    public:
    void setnumber()
    {
        cout<<"Enter the roll number of the student: ";
        cin>>rollno;
    }
    void getnumber()
    {
        cout<<"The roll number of the student is: "<<rollno<<endl;
    }
};

class test:virtual public student
{
    protected:
    float m1,m2,m3,m4,m5;
    public:
    void setmarks()
    {
        cout<<"Enter marks:\n";
        cout<<"Maths: ";
        cin>>m1;
        cout<<"Physics: ";
        cin>>m2;
        cout<<"Chemistry: ";
        cin>>m3;
        cout<<"Computer Science: ";
        cin>>m4;
        cout<<"English: ";
        cin>>m5;
    }
    void getmarks()
    {
        cout<<"The marks of the student are as follows:\n";
        cout<<"Maths: "<<m1<<endl;
        cout<<"Physics: "<<m2<<endl;
        cout<<"Chemistry: "<<m3<<endl;
        cout<<"Computer Science: "<<m4<<endl;
        cout<<"English: "<<m5<<endl;
    }
};

class result:virtual public student, public test
{
    private: 
    float total;
    public:
    void display()
    {
        total=(m1+m2+m3+m4+m5);
        getnumber();
        getmarks();
        cout<<"Total marks of the student are: "<<total<<endl;
    }
};

int main()
{
    result student1;
    student1.setnumber();
    student1.setmarks();
    student1.display();
    return 0;
}
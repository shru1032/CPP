/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//OOPS Open Ended with Inheritance and File Handling

#include <iostream>
#include <fstream>
#include <string.h>
using namespace std;

class Sona //Base Class
{
    public:
    int initTax, slot1, slot2, k, years;
    void getdata();
};

class Tax : public Sona //Derived Class
{
    protected:
    long long int tot_tax;
    
    public:
    int count;
    long long int tax[100];
    long long int sum(long long int arr[], int count);
    long long int total();
    void display_total();
};

void Sona::getdata()
{
    cout<<"Enter k: ";
    cin>>k;
    cout<<"Enter the initial tax: ";
    cin>>initTax;
    cout<<"Enter slot 1 years: ";
    cin>>slot1;
    cout<<"Enter slot 2 years: ";
    cin>>slot2;
    cout<<"Enter further years: ";
    cin>>years;
}

long long int Tax::sum(long long int arr[], int count)
{
   int i;
   long long int sum=0;
   for (i=0;i<count;i++)
   {
       sum=sum+arr[i];
   }
   return sum;
}

long long int Tax::total()
{
    count=1+slot1+slot2+years;
    tax[0]=initTax;
    int i,j;
    
    for (i=1;i<1+slot1;i++)
    {
        tax[i]=tax[i-1]+1;
    }
    for (i=slot1+1;i<1+slot1+slot2;i++)
    {
        tax[i]=2*tax[i-1];
    }
    for (i=1+slot1+slot2;i<1+slot1+slot2+years;i++)
    {
        long int t=1;
        int j;
        for (j=i-1;j>=i-k;j--)
        {
            t=t*tax[j];
        }
        tax[i]=t;
    }
    
    long long int tot_tax=sum(tax, count);
    return tot_tax;
}

void Tax::display_total()
{
    cout<<"Total tax units to be paid are: "<<total()<<" units"<<endl;
}

int main()
{
    int ch;
    fstream fl;
    do
    {
        Tax t1;
        t1.getdata();
        t1.total();
        t1.display_total();
        //Code to enter details into a text file
        fl.open("Tax", ios::app);
        if (!fl)
        {
            cout<<"File not created!\n";
        }
        else
        {
            int i;
            fl<<"\n---------------New Tax Assessment---------------\n";
            fl<<"Value of k: "<<t1.k<<endl;
            fl<<"Initial tax units: "<<t1.initTax<<" units"<<endl;
            fl<<"Number of slot 1 years: "<<t1.slot1<<" years"<<endl;
            fl<<"Number of slot 2 years: "<<t1.slot2<<" years"<<endl;
            fl<<"Further years following slot2 years: "<<t1.years<<" years"<<endl;
            fl<<"Total number of years: "<<t1.count<<" years"<<endl<<endl;
            fl<<"Tax in subsequent years is as follows:"<<endl;
            for (i=0;i<t1.count;i++)
            {
                fl<<"Tax in year-"<<i+1<<" : "<<t1.tax[i]<<" units"<<endl;
            }
            fl<<"Total tax to be paid after "<<t1.count<<" years: "<<t1.total()<<" units"<<endl;
            cout<<"Details added into the file.\n";
            fl.close();
        }
        cout<<"Press 1 to generate another total: ";
        cin>>ch;
    } while (ch==1);
    return 0;
}


/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <iostream>
#include <conio.h>
using namespace std;

class date
{
    int dd;
    int mm;
    int yyyy;
    public:
    date() //Constructor Overloading
    {
        dd=1;
        mm=1;
        yyyy=2021;
    }
    date(int a) //Constructor Overloading
    {
        dd=a;
        mm=1;
        yyyy=2021;
    }
    date(int a, int b) //Constructor Overloading
    {
        dd=a;
        mm=b;
        yyyy=2021;
    }
    date(int a, int b, int c) //Constructor Overloading
    {
        dd=a;
        mm=b;
        yyyy=c;
    }
    void display()
    {
        cout<<"The date is:\n";
        cout<<"DD/MM/YYYY: "<<dd<<"/"<<mm<<"/"<<yyyy<<endl;
    }
};

int main()
{
    date d1, d2(12), d3(20,3), d4(15,6,2002);
    d1.display();
    d2.display();
    d3.display();
    d4.display();
}

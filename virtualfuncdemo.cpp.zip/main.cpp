/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Program to demonstrate the use of virtual functions

#include <iostream>
using namespace std;

class base
{
    protected: 
    int x;
    public:
    base()
    {
        x=3;
    }
    virtual void print() //Virtual function
    {
        cout<<"Value of x in base class: "<<x<<endl;
    }
};

class derived: public base
{
    public:
    derived()
    {
        x=5;
    }
    void print() 
    {
        cout<<"Value of x in derived class: "<<x<<endl;
    }
};

int main()
{
    base *ptr;
    base b1;
    derived d1;
    cout<<"Inside base class:\n";
    ptr = &b1;
    ptr->print();
    cout<<"Inside derived class:\n";
    ptr = &d1;
    ptr->print();
    return 0;
}

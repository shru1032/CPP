/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class A 
{
    protected:
    int x;
    public:
    int get()
    {
        cout<<"Enter a number: ";
        cin>>x;
    }
    A()
    {
        cout<<"Inside A\n";
    }
    A(int c)
    {
        cout<<c<<"\n";
    }
};
class B:public A 
{
    public:
    B():A()
    {
        cout<<"Inside B\n";
    }
    B(int d):A(d)
    {
        cout<<d<<"\n";
    }
};
class C:private A 
{
    public:
    C():A()
    {
        cout<<"Inside C\n";
    }
    C(int e):A(e)
    {
        cout<<e<<"\n";
    }
};
int main()
{
    A a1(50), a2;
    a2.get();
    cout<<"Class B:\n";
    B b1(50), b2;
    b2.get();
    cout<<"Class C:\n";
    C c1(7), c2;
}

/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class dist 
{
    private:
    int feet;
    float inches;
    public:
    
    dist(int ft, float in)
    {
        feet=ft;
        inches=in;
    }
    void get()
    {
        cout<<"Enter feet= ";
        cin>>feet;
        cout<<"Enter inches= ";
        cin>>inches;
    }
    void show() const 
    {
        cout<<feet<<"-"<<inches;
    }
};
int main()
{
    const dist ball(300,0);
    //ball.get();
    ball.show();
}
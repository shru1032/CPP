/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

//Student Information

#include <iostream>
#include <string.h>
using namespace std;

class student
{
    protected:
    char name[100];
    int rollno;
    int marks;
    char grade[3];
    public:
    void input()
    {
        cout<<"Enter the student details here:\n";
        cout<<"Enter the name of the student: ";
        getline(cin,name);
        cout<<"Enter the roll no.: ";
        cin>>rollno;
        cout<<"Enter the marks: ";
        cin>>marks;
        cout<<"Enter grade: ";
        cin>>grade;
    }
};

class details : public student
{
    public:
    void display()
    {
        cout<<"The student details are as follows:\n";
        cout<<"Name: "<<name<<"\n";
        cout<<"Roll No.: "<<rollno<<"\n";
        cout<<"Marks: "<<marks<<"\n";
        cout<<"Grade: "<<grade<<"\n";
    }
};

int main()
{
    details student1;
    student1.input();
    student1.display();
    //student1.name; //Error
    return 0;
}

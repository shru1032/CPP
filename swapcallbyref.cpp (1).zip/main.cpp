/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
//Swapping 2 numbers using call by reference
#include <iostream>
using namespace std;

int main()
{
    int x,y;
    cout<<"Enter the first number: ";
    cin>>x;
    cout<<"Enter the second number: ";
    cin>>y;
    cout<<"Numbers before swapping are:\n";
    cout<<x<<"\t"<<y;
    swap(x,y);
    cout<<"\nNumbers after swapping are:\n";
    cout<<x<<"\t"<<y;
    return 0;
}

int swap(int *x, int *y)
{
    int temp;
    temp=*x;
    *x=*y;
    *x=temp;
    return 0;
}

/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// employee multiple inheritance

#include <iostream>
#include <string.h>
using namespace std;

class basicInfo
{
protected:
    string name;
    int empId;

public:
    void getBasicInfo(void)
    {
        cout << "Enter Name: ";
        cin >> name;
        cout << "Enter Emp. Id: ";
        cin >> empId;
    }
};

class deptInfo
{
protected:
    string deptName;
public:
    void getDeptInfo()
    {
        cout << "Enter Department Name: ";
        cin >> deptName;
    }
};

class employee : private basicInfo, private deptInfo
{
public:
    void getEmpInfo()
    {
        cout << "Enter employee's basic info: " << endl;
        getBasicInfo();
        cout<<endl;
        cout << "Enter employee's department info: " << endl;
        getDeptInfo();
        cout<<endl;
    }
    void displayEmpInfo()
    {
        cout << "\nEmployee Information:" << endl;
        cout << "Name: " << name << endl;
        cout << "Employee ID: " << empId << endl;
        cout << "Department Information:" << endl;
        cout << "Department Name: " << deptName << endl;
    }
};

int main()
{
    employee emp;

    emp.getEmpInfo();
    emp.displayEmpInfo();

    return 0;
}

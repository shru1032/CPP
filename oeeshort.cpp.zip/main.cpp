/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;

long long int sum(long long int arr[], int count)
{
   int i;
   long long int sum=0;
   for (i=0;i<count;i++)
   {
       sum=sum+arr[i];
   }
   return sum;
}
    
int main()
{
    int initTax, slot1, slot2, k, years;
    long long int tot_tax;
    cout<<"Enter k: ";
    cin>>k;
    cout<<"Enter the initial tax: ";
    cin>>initTax;
    cout<<"Enter slot 1 years: ";
    cin>>slot1;
    cout<<"Enter slot 2 years: ";
    cin>>slot2;
    cout<<"Enter further years: ";
    cin>>years;
    
    int count=1+slot1+slot2+years;
    long long int tax[100];
    tax[0]=initTax;
    int i,j;
    
    for (i=1;i<1+slot1;i++)
    {
        tax[i]=tax[i-1]+1;
    }
    for (i=slot1+1;i<1+slot1+slot2;i++)
    {
        tax[i]=2*tax[i-1];
    }
    for (i=1+slot1+slot2;i<1+slot1+slot2+years;i++)
    {
        long int t=1;
        int j;
        for (j=i-1;j>=i-k;j--)
        {
            t=t*tax[j];
        }
        tax[i]=t;
    }
    
    tot_tax=sum(tax, count);
    cout<<"Total tax units to be paid are: "<<tot_tax<<endl;
    
}
/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;

class complex 
{
    private:
    int real,img;
    public:
    complex(int r=0, int i=0)
    {
        real=r;
        img=i;
    }
    complex operator +(complex const &obj)
    {
        complex result;
        result.real=real+obj.real;
        result.img=img+obj.img;
        return result;
    }
    
    void print()
    {
        cout<<real<<"+"<<img<<"i"<<endl;
    }
};

int main()
{
    complex c1(1,2), c2(3,4);
    cout<<"Adding the 2 complex numbers, we get:\n";
    complex c3=c1+c2;
    c3.print();
    return 0;
}
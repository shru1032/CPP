/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// Program to caculate any number m raised to the power n
#include <iostream>
using namespace std;
float power(float m, int n=2);
int main()
{
    int n; float m;
    cout<<"Enter m: ";
    cin>>m;
    int a;
    float p;
    cout<<"Menu:\n";
    cout<<"1. To find square of m\n";
    cout<<"2. To find other powers of m\n";
    cout<<"3. Exit\n";
    cout<<"Enter your choice here: ";
    cin>>a;
    
    switch(a)
    {
        case 1:
        {
            p=power(m);
            cout<<"The square of "<<m<<" is "<<p;
            break;
        }
        case 2:
        {
            cout<<"Enter the exponential power: ";
            cin>>n;
            p=power(m,n);
            cout<<m<<" to the power "<<n<<" is "<<p;
            break;
        }
        case 3:
        {
            cout<<"The program has ended!";
            exit;
        }
    }
    return 0;
}

float power(float m, int n)
{
    float product=1;
    int i;
    for (i=0;i<n;i++)
    {
        product=product*m;
    }
    return product;
}

/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <iostream>
#include <cstdlib>
using namespace std;
static int temp;

class Time
{
    private:
    int hours,minutes;
    public:
    void input()
    {
        cout<<"Hours: ";
        cin>>hours;
        if(hours>=24)
        {
            hours=hours-24;
        }
        cout<<"Minutes: ";
        cin>>minutes;
        if (minutes>=60)
        {
            minutes=minutes%60;
            hours=hours+(minutes/60);
        }
    }
    void display()
    {
        cout<<hours<<":"<<minutes<<"\n";
    }
    int difference(Time a, Time b)
    {
        int t1,t2;
        t1= (a.hours*60)+(a.minutes);
        t2= (b.hours*60)+(b.minutes);
        int difference,temp,temp2;
        if(t1<t2)
        {
            difference=t2-t1;
            temp=difference;
            hours = difference/60;
            minutes = difference%60;
        }
        else if(t1>t2)
        {
            difference=t1-t2;
            temp=difference;
            hours = difference/60;
            minutes = difference%60;
        }
        return temp;
    }
    void city2Time(Time T1, Time T2, Time c, int temp)
    {
        if(T1.hours<T2.hours)
        {
            int t3,sum;
            t3= (c.hours*60)+(c.minutes);
            sum= t3+temp;
            hours=sum/60;
            minutes=sum%60;
        }
        else if(T1.hours>T2.hours)
        {
            int t3,sum;
            t3= (c.hours*60)+(c.minutes);
            sum= t3-temp;
            hours=sum/60;
            minutes=sum%60;
        }
    }
};
int main()
{
    Time city1,city2,diff,city1New,city2New;
    cout<<"Enter time for city-1:\n";
    city1.input();
    cout<<"Enter time for city-2:\n";
    city2.input();
    cout<<"Time in two cities is:\n";
    cout<<"City 1 -- ";
    city1.display();
    cout<<"City 2 -- ";
    city2.display();
    diff.difference(city1,city2);
    cout<<"Time difference between 2 cities is: \n";
    diff.display();
    cout<<"Enter City 1 time to find City 2 time:\n";
    city1New.input();
    cout<<"The City 2 time will be:\n";
    city2New.city2Time(city1,city2,city1New,diff.difference(city1,city2));
    city2New.display();
    return 0;
}
